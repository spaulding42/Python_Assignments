from operator import truediv


num1 = 42 #variable declaration: int
num2 = 2.3 #variable declaration: float
boolean = True  #variable declaration: boolean
string = 'Hello World' #variable declaration: string
pizza_toppings = ['Pepperoni', 'Sausage', 'Jalepenos', 'Cheese', 'Olives'] # initialize list
person = {'name': 'Devin', 'location': 'Salt Lake', 'age': 37, 'is_balding': True} #initialize dictionary
fruit = ('blueberry', 'strawberry', 'banana') #initialize Tuple
print(type(fruit))  #output: <class 'tuple'> access value
print(pizza_toppings[1])  #output: 'Sausage' add value
pizza_toppings.append('Mushrooms') # adds 'Mushrooms" to the end of pizza_toppings list add value
print(person['name'])   #output: 'Devin' access value
person['name'] = 'George'  # changes person['name'] to 'George' change value
person['eye_color'] = 'blue' # changes person['eye color'] to 'blue' change value
print(fruit[2])  #output: 'banana' access value

"""
2 conditional
if and else
"""
if num1 > 45:               # initial if statement
    print("It's greater")   # if true do this
else:                       # else if not true do this
    print("It's lower")     # output string

"""
3 conditional
if elif and else
"""
if len(string) < 5:           #    initial if statement
    print("It's a short word!")  # output string
elif len(string) > 15:           #  elif statement
    print("It's a long word!")   # output string
else:                            # final conditonal. if none other are true do this
    print("Just right!")         # output string

for x in range(5):               #for loop  5x
    print(x)                     # prints 0, 1, 2, 3, 4
for x in range(2,5):             #for loop x starts at 2 and goes while less than 5
    print(x)                     # prints 2, 3, 4
for x in range(2,10,3):          #for loop starts at 2 ends >= 10 and increments by 3
    print(x)                     #prints 2, 5, 8
x = 0                            # declares int x
while(x < 5):                    # while loop. condition x <5
    print(x)                     #outputs 0,1,2,3,4
    x += 1                       #increments x by 1

pizza_toppings.pop()             #removes final value in list 'mushrooms'
pizza_toppings.pop(1)            #removes list item at postion 1 'sausage'

print(person)                    #outputs {'name': 'George', 'location': 'Salt Lake', 'age': 37, 'is_balding': True, 'eye_color': 'blue'}
person.pop('eye_color')          # removes the 'eye_color' list item
print(person)                    # outputs {'name': 'George', 'location': 'Salt Lake', 'age': 37, 'is_balding': True}

for topping in pizza_toppings:   #for loop creating topping[i] var and will loop throuogh the length of pizza_toppings where i is the itteration through the loop
    if topping == 'Pepperoni':   #checks if pizza_topping[topping] == 'pepperoni'  (this will only be true the first time through since the other postions are some other topping)
        print(topping)           #prints pizza_toppings[0]  aka 'pepperoni
        continue                 #exit the if statement
    print('After 1st if statement')  # outputs 'After 1st if statement. this is not imbedded in a if statement so it will output it every time through the for loop
    if topping == 'Olives':      #is true once looping 4x then pizza_toppings[3] == 'olives' so it enters the if statement
        break                    #break out of the if & also the for loop

def print_hello_ten_times():     #defines a function called print_hello_ten_times
    for num in range(10):        #inside the fuction. for loop will go 10x
        print('Hello')           #prints "Hello" ten times

print_hello_ten_times()          #function is called

def print_hello_x_times(x):
    for num in range(x):
        print('Hello')

print_hello_x_times(4)

def print_hello_x_or_ten_times(x = 10):
    for num in range(x):
        print('Hello')

print_hello_x_or_ten_times()
print_hello_x_or_ten_times(4)


"""
Bonus section
"""

# print(num3)
# num3 = 72
# fruit[0] = 'cranberry'
# print(person['favorite_team'])
# print(pizza_toppings[7])
#   print(boolean)
# fruit.append('raspberry')
# fruit.pop(1)