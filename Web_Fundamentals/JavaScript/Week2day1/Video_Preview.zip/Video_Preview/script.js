console.log("page loaded...");

function playthis(elem){
    elem.play();
}

function stopthis(elem){
    elem.pause();
}