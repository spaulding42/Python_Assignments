from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)  
app.secret_key = 'keep it secret, keep it safe'

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    print(request.form)
    session['strawberry'] = request.form['strawberry']
    session['raspberry'] = request.form['raspberry']
    session['apple'] = request.form['apple']
    session['first_name'] = request.form['first_name']
    session['last_name'] = request.form['last_name']
    session['student_id'] = request.form['student_id']
    total_fruit = int(session['strawberry']) + int(session['raspberry']) + int(session['apple'])
    print(f"Charging {session['first_name']} {session['last_name']} (Student ID: {session['student_id']}) for {total_fruit} fruits")
    return redirect("/checked_out")

@app.route('/checked_out')
def checked_out():
    return render_template('checkout.html')

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    